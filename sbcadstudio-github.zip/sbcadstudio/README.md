# SB CAD Studio — Website Prototype

Multi-page corporate website prototype for **SB CAD Studio** (sbcadstudio.com) — a global technical drafting (AutoCAD shop drawings, millwork/joinery detailing) and 3D architectural CGI rendering studio serving the US, UAE/GCC, and UK/EU markets.

## Structure

```
sbcadstudio/
├── index.html          # Home
├── cad-services.html   # AutoCAD & Technical Shop Drawings
├── 3d-rendering.html   # 3D Architectural Visualization & CGI
├── portfolio.html      # Global Portfolio & Case Studies
├── about.html          # Studio & Workflow
├── contact.html        # Interactive Inquiry & Quote Estimator
└── assets/
    ├── css/
    │   ├── tokens.css  # design tokens (colors, type scale, spacing)
    │   └── main.css    # base styles + components
    └── js/
        └── main.js     # nav, live clocks, sliders, filters, quote wizard
```

## Stack

Static HTML5 + modular CSS (custom properties, Flexbox, Grid) + vanilla JS. No build step required — open `index.html` directly or serve the folder with any static host.

## PHP conversion

Each page marks the intended template boundaries with `<!-- header.php:start -->` / `<!-- header.php:end -->` and `<!-- footer.php:start -->` / `<!-- footer.php:end -->` comments, so the shared header/footer markup can be lifted into `header.php` / `footer.php` includes directly.

## Local preview

```bash
python3 -m http.server 8000
# then open http://localhost:8000
```
